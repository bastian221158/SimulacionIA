package prototype;

public class BotSoporteEstandar implements AsistenteVirtual {
    private String nombre = "SoporteAI";
    private String tono = "Formal";

    @Override
    public AsistenteVirtual clonar() {
        try {
            return (AsistenteVirtual) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }

    @Override
    public void personalizar(String nombre, String tono) {
        this.nombre = nombre;
        this.tono = tono;
    }

    @Override
    public String toString() {
        return "Asistente: " + nombre + " | Tono: " + tono;
    }
}
