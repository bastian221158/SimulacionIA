package prototype;

public interface AsistenteVirtual extends Cloneable {
    AsistenteVirtual clonar();
    void personalizar(String nombre, String tono);
}