package gui;

import javax.swing.*;
import iterator.*;

public class VentanaFlujoDialogo extends JFrame {
    public VentanaFlujoDialogo() {
        setTitle("Flujo de Diálogo");
        setSize(300, 250);
        setLayout(null);
        setLocationRelativeTo(null);

        JTextArea area = new JTextArea();
        area.setEditable(false);
        JScrollPane scroll = new JScrollPane(area);
        scroll.setBounds(20, 20, 250, 170);
        add(scroll);

        JButton cerrar = new JButton("Cerrar");
        cerrar.setBounds(100, 200, 90, 25);
        add(cerrar);

        cerrar.addActionListener(e -> dispose());

        // Crear flujo
        NodoDialogo p1 = new NodoDialogo("Hola, ¿cómo te ayudo?");
        NodoDialogo p2 = new NodoDialogo("¿Tienes cuenta?");
        NodoDialogo p3 = new NodoDialogo("¿Necesitas hablar con humano?");
        p1.siguiente = p2;
        p2.siguiente = p3;

        FlujoDialogo flujo = new FlujoDialogo(p1);
        for (NodoDialogo paso : flujo) {
            area.append(paso.pregunta + "\n");
        }
    }
}
