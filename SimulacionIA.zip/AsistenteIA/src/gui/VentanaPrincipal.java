package gui;

import javax.swing.*;
import prototype.*;
import singleton.*;
import adapter.*;

public class VentanaPrincipal extends JFrame {
    private JTextArea areaLog;

    public VentanaPrincipal() {
        setTitle("Asistente Virtual IA");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JButton btnCrearAsistente = new JButton("Crear Asistente");
        btnCrearAsistente.setBounds(30, 30, 180, 30);
        add(btnCrearAsistente);

        JButton btnVerFlujo = new JButton("Ver Flujo de Diálogo");
        btnVerFlujo.setBounds(30, 70, 180, 30);
        add(btnVerFlujo);

        JButton btnProbarCRM = new JButton("Probar CRM Adapter");
        btnProbarCRM.setBounds(30, 110, 180, 30);
        add(btnProbarCRM);

        JButton btnIA = new JButton("Llamar Motor IA");
        btnIA.setBounds(30, 150, 180, 30);
        add(btnIA);

        areaLog = new JTextArea();
        JScrollPane scroll = new JScrollPane(areaLog);
        scroll.setBounds(230, 30, 230, 300);
        add(scroll);

        btnCrearAsistente.addActionListener(e -> {
            AsistenteVirtual base = new BotSoporteEstandar();
            AsistenteVirtual nuevo = base.clonar();
            nuevo.personalizar("VirtualBotX", "Informal");
            areaLog.append("Asistente clonado: " + nuevo.toString() + "\n");
        });

        btnVerFlujo.addActionListener(e -> {
            new VentanaFlujoDialogo().setVisible(true);
        });

        btnProbarCRM.addActionListener(e -> {
            ICRM crm = new AdaptadorCRM();
            String nombre = crm.obtenerNombreCliente("123");
            areaLog.append("Cliente CRM: " + nombre + "\n");
        });

        btnIA.addActionListener(e -> {
            String respuesta = MotorIA.getInstancia().generarRespuesta("Necesito ayuda");
            areaLog.append("IA dice: " + respuesta + "\n");
        });
    }
}
