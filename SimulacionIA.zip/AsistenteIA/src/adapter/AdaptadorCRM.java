package adapter;

import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.io.*;

public class AdaptadorCRM implements ICRM {
    private CRMXmlAntiguo crmAntiguo = new CRMXmlAntiguo();

    @Override
    public String obtenerNombreCliente(String id) {
        try {
            String xml = crmAntiguo.obtenerClienteXML(id);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            InputStream is = new ByteArrayInputStream(xml.getBytes());
            Document doc = builder.parse(is);
            return doc.getElementsByTagName("nombre").item(0).getTextContent();
        } catch (Exception e) {
            return "Error al leer cliente";
        }
    }
}
