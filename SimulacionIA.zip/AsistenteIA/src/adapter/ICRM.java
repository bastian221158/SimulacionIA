package adapter;

public interface ICRM {
    String obtenerNombreCliente(String id);
}
