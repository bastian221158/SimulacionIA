package adapter;

public class CRMXmlAntiguo {
    public String obtenerClienteXML(String id) {
        return "<cliente><nombre>Juan</nombre></cliente>";
    }
}
