package iterator;

import java.util.Iterator;

public class FlujoDialogo implements Iterable<NodoDialogo> {
    private NodoDialogo inicio;

    public FlujoDialogo(NodoDialogo inicio) {
        this.inicio = inicio;
    }

    @Override
    public Iterator<NodoDialogo> iterator() {
        return new Iterator<NodoDialogo>() {
            private NodoDialogo actual = inicio;

            @Override
            public boolean hasNext() {
                return actual != null;
            }

            @Override
            public NodoDialogo next() {
                NodoDialogo temp = actual;
                actual = actual.siguiente;
                return temp;
            }
        };
    }
}
