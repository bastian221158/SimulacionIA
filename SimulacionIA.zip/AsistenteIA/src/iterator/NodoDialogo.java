package iterator;

public class NodoDialogo {
    public String pregunta;
    public NodoDialogo siguiente;

    public NodoDialogo(String pregunta) {
        this.pregunta = pregunta;
    }
}
