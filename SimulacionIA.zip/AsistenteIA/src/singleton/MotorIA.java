package singleton;

public class MotorIA {
    private static MotorIA instancia;

    private MotorIA() {}

    public static MotorIA getInstancia() {
        if (instancia == null) {
            instancia = new MotorIA();
        }
        return instancia;
    }

    public String generarRespuesta(String entrada) {
        return "IA responde: " + entrada;
    }
}
